
function Home() {
    return (
      <div className="page">
        <h1>Welcome to My Blog</h1>
        <p>This is a multi-page blog built with React Router.</p>
        <p>Check out the blog section to see my posts!</p>
      </div>
    );
  }
  
  export default Home;